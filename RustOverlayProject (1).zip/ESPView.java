package com.eni.rustoverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class ESPView extends View {
    private Paint boxPaint, textPaint;

    public ESPView(Context context) {
        super(context);
        boxPaint = new Paint();
        boxPaint.setColor(Color.GREEN);
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(3.0f);
        boxPaint.setAntiAlias(true);

        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(30.0f);
        textPaint.setAntiAlias(true);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        
        // رسم صندوق تجريبي للكشف (ESP Box) في منتصف الشاشة
        float l = canvas.getWidth() / 2f - 120;
        float t = canvas.getHeight() / 2f - 200;
        float r = canvas.getWidth() / 2f + 120;
        float b = canvas.getHeight() / 2f + 200;

        canvas.drawRect(l, t, r, b, boxPaint);
        canvas.drawText("LO_Enemy [10m]", l, t - 15, textPaint);

        invalidate(); // تحديث مستمر للإطارات
    }
}