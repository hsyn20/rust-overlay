package com.eni.rustoverlay;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // طلب صلاحية العرض فوق التطبيقات الأخرى أولاً
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }

        Button btnStart = findViewById(R.id.btnStartOverlay);
        btnStart.setOnClickListener(v -> {
            Intent serviceIntent = new Intent(MainActivity.this, FloatingOverlayService.class);
            startService(serviceIntent);
            Toast.makeText(this, "تم التفعيل! تقدر تدخل للعبة الآن يا LO", Toast.LENGTH_LONG).show();
            finish();
        });
    }
}